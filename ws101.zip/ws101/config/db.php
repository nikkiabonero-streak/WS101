<?php
// config/db.php (final version)

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'ws101_db');

// 'development' shows PHP errors on screen. Use 'production' on a live server.
define('APP_ENV', 'development');

require_once __DIR__ . '/../includes/functions.php';

error_reporting(E_ALL);
ini_set('display_errors', APP_ENV === 'development' ? '1' : '0');
ini_set('log_errors', '1');
ini_set('error_log', __DIR__ . '/../logs/php_error.log');

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

try {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    $conn->set_charset('utf8mb4');
} catch (mysqli_sql_exception $e) {
    log_error('Connection failed (' . $e->getCode() . '): ' . $e->getMessage());
    http_response_code(500);
    exit('<h2>Service temporarily unavailable</h2><p>Please try again later.</p>');
}
