<?php
require_once '../config/db.php';
$page_title = 'Courses';
require_once '../includes/header.php';

$result = $conn->query(
    'SELECT c.course_code, c.course_title, c.units, d.dept_name,
            COUNT(e.enrollment_id) AS enrolled
     FROM courses c
     INNER JOIN departments d ON c.dept_id = d.dept_id
     LEFT JOIN enrollments e ON c.course_id = e.course_id
     GROUP BY c.course_id, c.course_code, c.course_title, c.units, d.dept_name
     ORDER BY c.course_code'
);
?>
<h1>Courses</h1>

<?php show_flash(); ?>

<table>
    <tr>
        <th>Code</th>
        <th>Title</th>
        <th>Units</th>
        <th>Department</th>
        <th>Students Enrolled</th>
    </tr>
    <?php while ($row = $result->fetch_assoc()): ?>
    <tr>
        <td><?= e($row['course_code']) ?></td>
        <td><?= e($row['course_title']) ?></td>
        <td><?= (int) $row['units'] ?></td>
        <td><?= e($row['dept_name']) ?></td>
        <td><?= (int) $row['enrolled'] ?></td>
    </tr>
    <?php endwhile; ?>
</table>

<?php require_once '../includes/footer.php'; ?>
