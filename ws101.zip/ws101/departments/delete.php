<?php
require_once '../config/db.php';
require_once '../includes/functions.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('/departments/index.php');
}

$id = (int) ($_POST['dept_id'] ?? 0);

try {
    $stmt = $conn->prepare('DELETE FROM departments WHERE dept_id = ?');
    $stmt->bind_param('i', $id);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        set_flash('success', 'Department deleted.');
    } else {
        set_flash('error', 'Department not found.');
    }
    $stmt->close();

} catch (mysqli_sql_exception $e) {
    log_error('Delete department failed (ID ' . $id . '): ' . $e->getMessage());
    set_flash('error', friendly_db_message($e));
}

redirect('/departments/index.php');
