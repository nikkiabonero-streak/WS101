<?php
require_once '../config/db.php';
$page_title = 'Departments';
require_once '../includes/header.php';

$departments = get_departments($conn);
?>
<h1>Departments</h1>

<?php show_flash(); ?>

<table>
    <tr>
        <th>ID</th>
        <th>Department</th>
        <th>Actions</th>
    </tr>
    <?php foreach ($departments as $d): ?>
    <tr>
        <td><?= (int) $d['dept_id'] ?></td>
        <td><?= e($d['dept_name']) ?></td>
        <td>
            <form method="post" action="delete.php"
                  onsubmit="return confirm('Delete this department?');">
                <input type="hidden" name="dept_id" value="<?= (int) $d['dept_id'] ?>">
                <button type="submit" class="btn btn-delete">Delete</button>
            </form>
        </td>
    </tr>
    <?php endforeach; ?>
</table>

<?php require_once '../includes/footer.php'; ?>
