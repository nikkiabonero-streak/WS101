<?php
require_once '../config/db.php';
require_once '../includes/functions.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('/enrollments/index.php');
}

$id = (int) ($_POST['enrollment_id'] ?? 0);

try {
    $stmt = $conn->prepare('DELETE FROM enrollments WHERE enrollment_id = ?');
    $stmt->bind_param('i', $id);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        set_flash('success', 'Enrollment dropped.');
    } else {
        set_flash('error', 'Enrollment not found.');
    }
    $stmt->close();

} catch (mysqli_sql_exception $e) {
    log_error('Drop enrollment failed (ID ' . $id . '): ' . $e->getMessage());
    set_flash('error', friendly_db_message($e));
}

redirect('/enrollments/index.php');
