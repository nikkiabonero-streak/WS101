<?php
require_once '../config/db.php';
$page_title = 'Enrollments';
require_once '../includes/header.php';

$result = $conn->query(
    'SELECT e.enrollment_id, s.student_no, s.first_name, s.last_name,
            c.course_code, c.course_title, e.school_year, e.grade
     FROM enrollments e
     INNER JOIN students s ON e.student_id = s.student_id
     INNER JOIN courses  c ON e.course_id  = c.course_id
     ORDER BY e.school_year DESC, s.last_name, c.course_code'
);
?>
<h1>Enrollments</h1>

<?php show_flash(); ?>

<?php if ($result->num_rows === 0): ?>
    <p>No enrollments yet.</p>
<?php else: ?>
<table>
    <tr>
        <th>Student</th>
        <th>Course</th>
        <th>School Year</th>
        <th>Grade</th>
        <th>Actions</th>
    </tr>
    <?php while ($row = $result->fetch_assoc()): ?>
    <tr>
        <td><?= e($row['last_name'] . ', ' . $row['first_name']) ?>
            (<?= e($row['student_no']) ?>)</td>
        <td><?= e($row['course_code'] . ' - ' . $row['course_title']) ?></td>
        <td><?= e($row['school_year']) ?></td>
        <td><?= $row['grade'] === null
                ? 'Not yet graded'
                : e(number_format((float) $row['grade'], 2)) ?></td>
        <td>
            <form method="post" action="delete.php"
                  onsubmit="return confirm('Drop this enrollment?');">
                <input type="hidden" name="enrollment_id"
                       value="<?= (int) $row['enrollment_id'] ?>">
                <button type="submit" class="btn btn-delete">Drop</button>
            </form>
        </td>
    </tr>
    <?php endwhile; ?>
</table>
<?php endif; ?>

<?php require_once '../includes/footer.php'; ?>
