<?php
// includes/functions.php

if (session_status() === PHP_SESSION_NONE) {
    session_start();               // needed for flash messages
}

define('BASE_URL', '/ws101');      // folder name inside htdocs

// Escape output to prevent XSS.
function e($value)
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

// Store a one-time message that survives a redirect.
function set_flash($type, $message)
{
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

// Print the message once, then remove it.
function show_flash()
{
    if (!empty($_SESSION['flash'])) {
        $f = $_SESSION['flash'];
        echo '<div class="alert alert-' . e($f['type']) . '">' . e($f['message']) . '</div>';
        unset($_SESSION['flash']);
    }
}

function redirect($path)
{
    header('Location: ' . BASE_URL . $path);
    exit;                          // always stop the script after a redirect
}

// All departments for dropdown lists.
function get_departments($conn)
{
    $result = $conn->query('SELECT dept_id, dept_name FROM departments ORDER BY dept_name');
    return $result->fetch_all(MYSQLI_ASSOC);
}

// Write a technical message to logs/error.log with a timestamp.
function log_error($message)
{
    $file = __DIR__ . '/../logs/error.log';
    $line = '[' . date('Y-m-d H:i:s') . '] ' . $message . PHP_EOL;
    file_put_contents($file, $line, FILE_APPEND | LOCK_EX);
}

// Convert a MySQL error code into a message that is safe to show users.
function friendly_db_message(mysqli_sql_exception $e)
{
    return match ((int) $e->getCode()) {
        1062    => 'That value already exists. Please use a different one.',
        1451    => 'This record cannot be deleted because other records depend on it.',
        1452    => 'The related record you selected does not exist.',
        default => 'A database error occurred. Please try again later.',
    };
}
