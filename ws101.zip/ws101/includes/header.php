<?php
// includes/header.php
require_once __DIR__ . '/functions.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($page_title ?? 'WS101 System') ?></title>
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/style.css">
</head>
<body>
<nav>
    <a href="<?= BASE_URL ?>/index.php">Home</a>
    <a href="<?= BASE_URL ?>/students/index.php">Students</a>
    <a href="<?= BASE_URL ?>/courses/index.php">Courses</a>
    <a href="<?= BASE_URL ?>/enrollments/index.php">Enrollments</a>
    <a href="<?= BASE_URL ?>/departments/index.php">Departments</a>
</nav>
<div class="container">
