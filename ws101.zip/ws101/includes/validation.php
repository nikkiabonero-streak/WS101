<?php
// includes/validation.php
require_once __DIR__ . '/functions.php';

// Trim and collapse repeated spaces.
function clean($value)
{
    return trim(preg_replace('/\s+/', ' ', (string) $value));
}

// Helpers used inside the HTML form.
function field_error($errors, $name)
{
    return isset($errors[$name])
        ? '<div class="error-text">' . e($errors[$name]) . '</div>'
        : '';
}

function field_class($errors, $name)
{
    return isset($errors[$name]) ? 'invalid' : '';
}

/**
 * Validate student data.
 * $ignore_id is the student's own ID when editing, so the record
 * does not count as a duplicate of itself (use 0 when creating).
 */
function validate_student($conn, array $data, $ignore_id = 0)
{
    $errors = [];

    // 1. Student number
    if ($data['student_no'] === '') {
        $errors['student_no'] = 'Student number is required.';
    } elseif (!preg_match('/^\d{4}-\d{4}$/', $data['student_no'])) {
        $errors['student_no'] = 'Use the format 2024-0001.';
    } else {
        $stmt = $conn->prepare(
            'SELECT 1 FROM students WHERE student_no = ? AND student_id <> ?'
        );
        $stmt->bind_param('si', $data['student_no'], $ignore_id);
        $stmt->execute();
        if ($stmt->get_result()->num_rows > 0) {
            $errors['student_no'] = 'This student number is already registered.';
        }
        $stmt->close();
    }

    // 2. First and last name
    $names = ['first_name' => 'First name', 'last_name' => 'Last name'];
    foreach ($names as $field => $label) {
        $value = $data[$field];
        if ($value === '') {
            $errors[$field] = $label . ' is required.';
        } elseif (mb_strlen($value) < 2 || mb_strlen($value) > 50) {
            $errors[$field] = $label . ' must be 2 to 50 characters long.';
        } elseif (!preg_match("/^[\p{L}][\p{L} .'\-]*$/u", $value)) {
            $errors[$field] = $label . ' may contain letters only.';
        }
    }

    // 3. Email
    if ($data['email'] === '') {
        $errors['email'] = 'Email is required.';
    } elseif (strlen($data['email']) > 100
              || !filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = 'Enter a valid email address.';
    } else {
        $stmt = $conn->prepare(
            'SELECT 1 FROM students WHERE email = ? AND student_id <> ?'
        );
        $stmt->bind_param('si', $data['email'], $ignore_id);
        $stmt->execute();
        if ($stmt->get_result()->num_rows > 0) {
            $errors['email'] = 'This email is already registered.';
        }
        $stmt->close();
    }

    // 4. Department
    $dept_id = filter_var($data['dept_id'], FILTER_VALIDATE_INT);
    if ($dept_id === false || $dept_id <= 0) {
        $errors['dept_id'] = 'Please select a department.';
    } else {
        $stmt = $conn->prepare('SELECT 1 FROM departments WHERE dept_id = ?');
        $stmt->bind_param('i', $dept_id);
        $stmt->execute();
        if ($stmt->get_result()->num_rows === 0) {
            $errors['dept_id'] = 'Selected department does not exist.';
        }
        $stmt->close();
    }

    return $errors;
}
