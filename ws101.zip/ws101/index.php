<?php
require_once 'config/db.php';
$page_title = 'Home';
require_once 'includes/header.php';

// Table names come from this fixed list, never from user input.
$counts = [];
foreach (['students', 'courses', 'departments', 'enrollments'] as $table) {
    $result = $conn->query('SELECT COUNT(*) AS total FROM ' . $table);
    $counts[$table] = (int) $result->fetch_assoc()['total'];
}
?>
<h1>WS101 Student System</h1>

<?php show_flash(); ?>

<ul>
    <li><a href="<?= BASE_URL ?>/students/index.php">Students</a>: <?= $counts['students'] ?></li>
    <li><a href="<?= BASE_URL ?>/courses/index.php">Courses</a>: <?= $counts['courses'] ?></li>
    <li><a href="<?= BASE_URL ?>/departments/index.php">Departments</a>: <?= $counts['departments'] ?></li>
    <li><a href="<?= BASE_URL ?>/enrollments/index.php">Enrollments</a>: <?= $counts['enrollments'] ?></li>
</ul>

<?php require_once 'includes/footer.php'; ?>
