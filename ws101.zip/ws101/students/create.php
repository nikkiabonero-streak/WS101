<?php
require_once '../config/db.php';
require_once '../includes/functions.php';
require_once '../includes/validation.php';

$departments = get_departments($conn);
$errors = [];
$old = ['student_no' => '', 'first_name' => '', 'last_name' => '',
        'email' => '', 'dept_id' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 1. Collect and clean
    $old = [
        'student_no' => clean($_POST['student_no'] ?? ''),
        'first_name' => clean($_POST['first_name'] ?? ''),
        'last_name'  => clean($_POST['last_name'] ?? ''),
        'email'      => strtolower(clean($_POST['email'] ?? '')),
        'dept_id'    => $_POST['dept_id'] ?? '',
    ];

    // 2. Validate
    $errors = validate_student($conn, $old);

    // 3. Save only if there are no errors
    if (empty($errors)) {
        $dept_id = (int) $old['dept_id'];

        try {
            $stmt = $conn->prepare(
                'INSERT INTO students (student_no, first_name, last_name, email, dept_id)
                 VALUES (?, ?, ?, ?, ?)'
            );
            $stmt->bind_param('ssssi', $old['student_no'], $old['first_name'],
                              $old['last_name'], $old['email'], $dept_id);
            $stmt->execute();
            $stmt->close();

            set_flash('success', 'Student added successfully.');
            redirect('/students/index.php');

        } catch (mysqli_sql_exception $e) {
            log_error('Insert student failed: ' . $e->getMessage());
            $errors['general'] = friendly_db_message($e);
        }
    }
}

$page_title = 'Add Student';
require_once '../includes/header.php';
?>
<h1>Add Student</h1>

<?php if (isset($errors['general'])): ?>
    <div class="alert alert-error"><?= e($errors['general']) ?></div>
<?php elseif (!empty($errors)): ?>
    <div class="alert alert-error">Please fix the errors below and try again.</div>
<?php endif; ?>

<form method="post" action="create.php">
    <label for="student_no">Student Number</label>
    <input type="text" id="student_no" name="student_no" maxlength="20" required
           class="<?= field_class($errors, 'student_no') ?>"
           value="<?= e($old['student_no']) ?>" placeholder="2024-0001">
    <?= field_error($errors, 'student_no') ?>

    <label for="first_name">First Name</label>
    <input type="text" id="first_name" name="first_name" maxlength="50" required
           class="<?= field_class($errors, 'first_name') ?>"
           value="<?= e($old['first_name']) ?>">
    <?= field_error($errors, 'first_name') ?>

    <label for="last_name">Last Name</label>
    <input type="text" id="last_name" name="last_name" maxlength="50" required
           class="<?= field_class($errors, 'last_name') ?>"
           value="<?= e($old['last_name']) ?>">
    <?= field_error($errors, 'last_name') ?>

    <label for="email">Email</label>
    <input type="email" id="email" name="email" maxlength="100" required
           class="<?= field_class($errors, 'email') ?>"
           value="<?= e($old['email']) ?>">
    <?= field_error($errors, 'email') ?>

    <label for="dept_id">Department</label>
    <select id="dept_id" name="dept_id" required
            class="<?= field_class($errors, 'dept_id') ?>">
        <option value="">-- Select department --</option>
        <?php foreach ($departments as $d): ?>
            <option value="<?= (int) $d['dept_id'] ?>"
                <?= (string) $old['dept_id'] === (string) $d['dept_id'] ? 'selected' : '' ?>>
                <?= e($d['dept_name']) ?>
            </option>
        <?php endforeach; ?>
    </select>
    <?= field_error($errors, 'dept_id') ?>

    <div class="actions">
        <button type="submit" class="btn">Save</button>
        <a href="index.php" class="btn btn-gray">Cancel</a>
    </div>
</form>

<?php require_once '../includes/footer.php'; ?>
