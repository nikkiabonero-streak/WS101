<?php
require_once '../config/db.php';
require_once '../includes/functions.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('/students/index.php');
}

$id = (int) ($_POST['student_id'] ?? 0);

try {
    $stmt = $conn->prepare('DELETE FROM students WHERE student_id = ?');
    $stmt->bind_param('i', $id);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        set_flash('success', 'Student deleted.');
    } else {
        set_flash('error', 'Student not found.');
    }
    $stmt->close();

} catch (mysqli_sql_exception $e) {
    log_error('Delete student failed (ID ' . $id . '): ' . $e->getMessage());
    set_flash('error', friendly_db_message($e));
}

redirect('/students/index.php');
