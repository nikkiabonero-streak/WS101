<?php
require_once '../config/db.php';
require_once '../includes/functions.php';
require_once '../includes/validation.php';

$id = (int) ($_GET['id'] ?? $_POST['student_id'] ?? 0);

// Load the existing record.
$stmt = $conn->prepare('SELECT * FROM students WHERE student_id = ?');
$stmt->bind_param('i', $id);
$stmt->execute();
$student = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$student) {
    set_flash('error', 'Student not found.');
    redirect('/students/index.php');
}

$departments = get_departments($conn);
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $old = [
        'student_no' => clean($_POST['student_no'] ?? ''),
        'first_name' => clean($_POST['first_name'] ?? ''),
        'last_name'  => clean($_POST['last_name'] ?? ''),
        'email'      => strtolower(clean($_POST['email'] ?? '')),
        'dept_id'    => $_POST['dept_id'] ?? '',
    ];

    // Pass $id so the record is not flagged as a duplicate of itself.
    $errors = validate_student($conn, $old, $id);

    if (empty($errors)) {
        $dept_id = (int) $old['dept_id'];

        try {
            $stmt = $conn->prepare(
                'UPDATE students
                 SET student_no = ?, first_name = ?, last_name = ?, email = ?, dept_id = ?
                 WHERE student_id = ?'
            );
            $stmt->bind_param('ssssii', $old['student_no'], $old['first_name'],
                              $old['last_name'], $old['email'], $dept_id, $id);
            $stmt->execute();
            $stmt->close();

            set_flash('success', 'Student updated successfully.');
            redirect('/students/index.php');

        } catch (mysqli_sql_exception $e) {
            log_error('Update student failed: ' . $e->getMessage());
            $errors['general'] = friendly_db_message($e);
        }
    }

    // On failure, show what the user typed instead of the saved values.
    $student = array_merge($student, $old);
}

$page_title = 'Edit Student';
require_once '../includes/header.php';
?>
<h1>Edit Student</h1>

<?php if (isset($errors['general'])): ?>
    <div class="alert alert-error"><?= e($errors['general']) ?></div>
<?php elseif (!empty($errors)): ?>
    <div class="alert alert-error">Please fix the errors below and try again.</div>
<?php endif; ?>

<form method="post" action="edit.php">
    <input type="hidden" name="student_id" value="<?= (int) $student['student_id'] ?>">

    <label for="student_no">Student Number</label>
    <input type="text" id="student_no" name="student_no" maxlength="20" required
           class="<?= field_class($errors, 'student_no') ?>"
           value="<?= e($student['student_no']) ?>">
    <?= field_error($errors, 'student_no') ?>

    <label for="first_name">First Name</label>
    <input type="text" id="first_name" name="first_name" maxlength="50" required
           class="<?= field_class($errors, 'first_name') ?>"
           value="<?= e($student['first_name']) ?>">
    <?= field_error($errors, 'first_name') ?>

    <label for="last_name">Last Name</label>
    <input type="text" id="last_name" name="last_name" maxlength="50" required
           class="<?= field_class($errors, 'last_name') ?>"
           value="<?= e($student['last_name']) ?>">
    <?= field_error($errors, 'last_name') ?>

    <label for="email">Email</label>
    <input type="email" id="email" name="email" maxlength="100" required
           class="<?= field_class($errors, 'email') ?>"
           value="<?= e($student['email']) ?>">
    <?= field_error($errors, 'email') ?>

    <label for="dept_id">Department</label>
    <select id="dept_id" name="dept_id" required
            class="<?= field_class($errors, 'dept_id') ?>">
        <?php foreach ($departments as $d): ?>
            <option value="<?= (int) $d['dept_id'] ?>"
                <?= $d['dept_id'] == $student['dept_id'] ? 'selected' : '' ?>>
                <?= e($d['dept_name']) ?>
            </option>
        <?php endforeach; ?>
    </select>
    <?= field_error($errors, 'dept_id') ?>

    <div class="actions">
        <button type="submit" class="btn">Update</button>
        <a href="index.php" class="btn btn-gray">Cancel</a>
    </div>
</form>

<?php require_once '../includes/footer.php'; ?>
