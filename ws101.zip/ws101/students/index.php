<?php
require_once '../config/db.php';
$page_title = 'Students';
require_once '../includes/header.php';

$search = trim($_GET['search'] ?? '');

$base_sql = 'SELECT s.student_id, s.student_no, s.first_name, s.last_name,
                    s.email, d.dept_name
             FROM students s
             INNER JOIN departments d ON s.dept_id = d.dept_id';

if ($search !== '') {
    $like = '%' . $search . '%';
    $stmt = $conn->prepare($base_sql .
        ' WHERE s.first_name LIKE ? OR s.last_name LIKE ? OR s.student_no LIKE ?
          ORDER BY s.last_name, s.first_name');
    $stmt->bind_param('sss', $like, $like, $like);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $result = $conn->query($base_sql . ' ORDER BY s.last_name, s.first_name');
}
?>
<h1>Students</h1>

<?php show_flash(); ?>

<form method="get" action="index.php">
    <input type="text" name="search" placeholder="Search by name or student number"
           value="<?= e($search) ?>">
    <div class="actions">
        <button type="submit" class="btn">Search</button>
        <a href="index.php" class="btn btn-gray">Reset</a>
        <a href="create.php" class="btn">+ Add Student</a>
    </div>
</form>

<?php if ($result->num_rows === 0): ?>
    <p>No students found.</p>
<?php else: ?>
<table>
    <tr>
        <th>Student No.</th>
        <th>Name</th>
        <th>Email</th>
        <th>Department</th>
        <th>Actions</th>
    </tr>
    <?php while ($row = $result->fetch_assoc()): ?>
    <tr>
        <td><?= e($row['student_no']) ?></td>
        <td><?= e($row['last_name'] . ', ' . $row['first_name']) ?></td>
        <td><?= e($row['email']) ?></td>
        <td><?= e($row['dept_name']) ?></td>
        <td>
            <a href="edit.php?id=<?= (int) $row['student_id'] ?>" class="btn btn-edit">Edit</a>
            <form method="post" action="delete.php"
                  onsubmit="return confirm('Delete this student?');">
                <input type="hidden" name="student_id" value="<?= (int) $row['student_id'] ?>">
                <button type="submit" class="btn btn-delete">Delete</button>
            </form>
        </td>
    </tr>
    <?php endwhile; ?>
</table>
<?php endif; ?>

<?php require_once '../includes/footer.php'; ?>
