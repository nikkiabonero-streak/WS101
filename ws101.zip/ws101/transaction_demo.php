<?php
require_once 'config/db.php';

$conn->begin_transaction();

try {
    // Step 1: insert the student
    $stmt = $conn->prepare(
        'INSERT INTO students (student_no, first_name, last_name, email, dept_id)
         VALUES (?, ?, ?, ?, ?)'
    );
    $no = '2024-0010'; $fn = 'Rosa'; $ln = 'Villanueva';
    $em = 'rosa.v@example.com'; $dept = 1;
    $stmt->bind_param('ssssi', $no, $fn, $ln, $em, $dept);
    $stmt->execute();
    $new_id = $conn->insert_id;
    $stmt->close();

    // Step 2: insert the matching profile (one-to-one)
    $stmt = $conn->prepare(
        'INSERT INTO student_profiles (student_id, address, contact_no, birthdate)
         VALUES (?, ?, ?, ?)'
    );
    $addr = '8 Sampaguita Street'; $contact = '09191234567'; $bday = '2005-07-21';
    $stmt->bind_param('isss', $new_id, $addr, $contact, $bday);
    $stmt->execute();
    $stmt->close();

    $conn->commit();        // make both inserts permanent
    echo 'Student and profile saved.';

} catch (mysqli_sql_exception $e) {
    $conn->rollback();      // undo everything since begin_transaction()
    log_error('Transaction failed: ' . $e->getMessage());
    echo 'Nothing was saved. Please try again.';
}
